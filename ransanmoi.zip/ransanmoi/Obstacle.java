package ransanmoi;

import java.awt.*;
import java.util.List;

public class Obstacle {

    // ====== Danh sách các tile mà obstacle chiếm ======
    private List<Point> tiles;

    // ====== Tên hoặc loại obstacle ======
    private String type;    // ví dụ: "rock", "tree", "wall"

    // ====== Ảnh obstacle (chưa load, chỉ giữ chỗ) ======
    // public Image image;  // sau này sẽ gán từ ImageAssets

    // ====== Constructor ======
    public Obstacle(String type, List<Point> tiles) {
        this.type = type;
        this.tiles = tiles;
    }

    // ====== Getter ======
    public List<Point> getTiles() {
        return tiles;
    }

    public String getType() {
        return type;
    }

    // ====== Dành cho tương lai ======
    // public void setImage(Image img) {
    //     this.image = img;
    // }

    // public Image getImage() {
    //     return image;
    // }
}
