package ransanmoi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WinPanel extends JPanel {

    private MainFrame frame;

    private JLabel restartLabel;
    private JLabel menuLabel;

    public WinPanel(MainFrame frame) {
        this.frame = frame;

        setLayout(null); // sử dụng toạ độ tuyệt đối

        // ====== LOAD ẢNH ======
        Image restartImg = ImageAssets.restart;   // thêm biến trong ImageAssets
        Image menuImg    = ImageAssets.menu;      // cũng thêm vào ImageAssets

        // ====== TẠO LABEL ======
        restartLabel = new JLabel(new ImageIcon(restartImg));
        menuLabel    = new JLabel(new ImageIcon(menuImg));

        // ====== ĐẶT VỊ TRÍ (chỉnh lại tuỳ bạn) ======
        restartLabel.setBounds(
                450,
                350,
                restartImg.getWidth(null),
                restartImg.getHeight(null));

        menuLabel.setBounds(
                450,
                480,
                menuImg.getWidth(null),
                menuImg.getHeight(null));

        // ====== CLICK ======
        restartLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(GameConfig.easy());  // restart map easy
            }
        });

        menuLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.showMenu();
            }
        });

        // ====== THÊM COMPONENT ======
        add(restartLabel);
        add(menuLabel);
    }

    // ====== BACKGROUND ======
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(ImageAssets.bgWin, 0, 0, getWidth(), getHeight(), null);
    }
}
