package ransanmoi;

import java.awt.Point;
import java.util.List;

public class GameConfig {

    // ====== Thông số cơ bản của map ======
    public int mapWidth;         // số ô ngang
    public int mapHeight;        // số ô dọc
    public int speed;            // tốc độ game (ms của Timer)
    public int scoreToWin;       // điểm cần đạt

    // ====== Mục tiêu thắng màn ======
    public Point goalPoint;      // vị trí người chơi phải chạm

    // ====== Danh sách vật cản (toạ độ tile) ======
    public List<Point> obstacles;

    // ====== Hình nền map (dùng sau khi tích hợp ImageAssets) ======
    // public Image background;  // hiện tại chưa set, chỉ giữ chỗ

    // ====== Constructor rỗng ======
    public GameConfig() {
        // chưa làm gì, chỉ khởi tạo khung
    }

    // ====== Static config cho từng map (để khai báo sau này) ======
    public static GameConfig easy() {
        return new GameConfig();
    }

    public static GameConfig normal() {
        return new GameConfig();
    }

    public static GameConfig hard() {
        return new GameConfig();
    }
}
