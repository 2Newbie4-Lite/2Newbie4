package ransanmoi;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import ransanmoi.Snake.Direction;
import ransanmoi.ImageAssets;

public class Game extends JPanel implements ActionListener, KeyListener {

    private MainFrame frame;

    private final int TILE_SIZE = 20;
    private final int DELAY = 100;

    private final GameBoard board;
    private Snake snake;
    private Food food;

    private boolean running = true;
    private Timer timer;

    public Game(GameConfig config, MainFrame frame) {
        this.frame = frame;

        board = new GameBoard(60, 45);
        snake = new Snake(new Point(10, 10));
        food = new Food(board.getWidth(), board.getHeight());

        timer = new Timer(DELAY, this);
        timer.start();

        setPreferredSize(new Dimension(board.getWidth() * TILE_SIZE, board.getHeight() * TILE_SIZE));
        setBackground(Color.WHITE);

        setFocusable(true);
        addKeyListener(this);
        //Game bị phải click lại màn hình mới chạy
        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) update();
        repaint();
    }

    private void update() {

        // Tính vị trí đầu mới
        Point nextHead = new Point(snake.getHead());
        switch (snake.getDirection()) {
            case UP -> nextHead.y--;
            case DOWN -> nextHead.y++;
            case LEFT -> nextHead.x--;
            case RIGHT -> nextHead.x++;
        }

        // Va vào thân → thua
        if (snake.contains(nextHead)) {
            running = false;
            frame.showLose();
            return;
        }

        snake.move(board.getWidth(), board.getHeight());

        // Ăn food
        if (snake.getHead().equals(food.getPosition())) {
            snake.grow();
            food.respawn(board.getWidth(), board.getHeight());
        }
    }

    // Không còn dùng nữa; LosePanel xử lý rồi
    private void resetGame() {
        snake = new Snake(new Point(10, 10));
        food.respawn(board.getWidth(), board.getHeight());
        running = true;
        timer.restart();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Vẽ background
        g.drawImage(ImageAssets.bgEasy, 0, 0, getWidth(), getHeight(), null);

        // Vẽ food
        Point f = food.getPosition();
        g.drawImage(ImageAssets.food1,
                f.x * TILE_SIZE, f.y * TILE_SIZE,
                TILE_SIZE, TILE_SIZE,
                null);

        // ===== VẼ RẮN =====

        // 1) Vẽ đầu RẮN
        Point head = snake.getHead();
        g.drawImage(ImageAssets.snakeHead,
                head.x * TILE_SIZE, head.y * TILE_SIZE,
                TILE_SIZE, TILE_SIZE,
                null);

        // 2) Vẽ thân (bỏ phần tử đầu để tránh vẽ đè)
        java.util.List<Point> body = snake.getBody();
        for (int i = 1; i < body.size(); i++) {
            Point p = body.get(i);

            g.drawImage(ImageAssets.snakeBody,
                    p.x * TILE_SIZE, p.y * TILE_SIZE,
                    TILE_SIZE, TILE_SIZE,
                    null);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> snake.setDirection(Direction.UP);
            case KeyEvent.VK_DOWN -> snake.setDirection(Direction.DOWN);
            case KeyEvent.VK_LEFT -> snake.setDirection(Direction.LEFT);
            case KeyEvent.VK_RIGHT -> snake.setDirection(Direction.RIGHT);
        }
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
}
