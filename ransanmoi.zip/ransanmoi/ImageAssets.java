package ransanmoi;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.io.IOException;

public class ImageAssets {

    // ====== Background của các map ======
    public static Image bgEasy;
    public static Image bgNormal;
    public static Image bgHard;

    // ====== Background của các màn ======
    public static Image bgMenu;
    public static Image bgDifficulty;
    public static Image bgWin;
    public static Image bgLose;

    // ====== Snake ======
    public static Image snakeHead;
    public static Image snakeBody;

    // ====== Food ======
    public static Image food1;   // food cơ bản
    public static Image food2;   // food nâng cao (tùy bạn có hay không)

    // ====== Sau này có thể thêm OBSTACLE ======
    public static Image obstacle1;
    //====Nút====
    public static Image start;
    public static Image exit;
    public static Image choose2;
    public static Image choose1;
    public static Image choose3;
    public static Image back;
    public static Image restart;
    public static Image menu;
    

    // Static block: load ảnh ngay khi class được sử dụng lần đầu
    static {
        loadAssets();
    }

    // Load từng ảnh, xử lý lỗi
    private static void loadAssets() {
        try {
            // ==== Map Backgrounds ====
            bgEasy = load("/ransanmoi/assets/images/Background.png");
            bgNormal = load("/ransanmoi/assets/images/Background.png");
            bgHard = load("/ransanmoi/assets/images/Background.png");

            // ==== Screen Backgrounds ====
            bgMenu = load("/ransanmoi/assets/images/Background.png");
            bgDifficulty = load("/ransanmoi/assets/images/Background.png");
            bgWin = load("/ransanmoi/assets/images/Background.png");
            bgLose = load("/ransanmoi/assets/images/Background.png");

            // ==== Snake ====
            snakeHead = load("/ransanmoi/assets/images/Head.png");
            snakeBody = load("/ransanmoi/assets/images/Body.png");

            // ==== Food ====
            food1 = load("/ransanmoi/assets/images/food.png");
            food2 = load("/ransanmoi/assets/images/food.png");

            // ==== Obstacle ====
            obstacle1 = load("/ransanmoi/assets/images/obstacle01.png");
            //===Nuts===
            start=load("/ransanmoi/assets/images/Start.png");
            exit=load("/ransanmoi/assets/images/Exit.png");
            choose1=load("/ransanmoi/assets/images/Choose1.png");
            choose2=load("/ransanmoi/assets/images/Choose2.png");
            choose3=load("/ransanmoi/assets/images/Choose3.png");
            back=load("/ransanmoi/assets/images/Back.png");
            restart=load("/ransanmoi/assets/images/Restart.png");
            menu=load("/ransanmoi/assets/images/Menu.png");
                                

        } catch (Exception e) {
            System.out.println("❌ Lỗi khi load ảnh: " + e.getMessage());
        }
    }

    // Hàm load ảnh chung
    private static Image load(String path) throws IOException {
        return ImageIO.read(ImageAssets.class.getResource(path));
    }
}
