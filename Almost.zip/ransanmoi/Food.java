package ransanmoi;

import java.awt.Point;//Biểu diễn tạo độ thức ăn (x,y)
import java.util.List;
import java.util.Random;//Sinh vị trí ngẫu nhiên

public class Food {
    //Vị trí của food
    private Point position;
    //Tạo số ngẫu nhiên
    private Random rand = new Random();

    //Hàm khởi tạo constructor
    public Food(int maxX, int maxY) {
        
    }
    //Cho Game và GameBoard truy cập
    public Point getPosition() {
        return position;
    }
    //Sinh tại vị trí ngẫu nhiên
    public void respawn(int maxX, int maxY, List<Point> obstacles, Snake snake) {
        Point p;
        do {
            p = new Point(rand.nextInt(maxX), rand.nextInt(maxY));
        } while (snake.contains(p)
                || // không trùng thân rắn
                obstacles.contains(p) // không trùng obstacle tile
                );

        position = p;
    }
    /*@Deprecated
    public void respawn(int maxX, int maxY) {
        
    }*/

}
