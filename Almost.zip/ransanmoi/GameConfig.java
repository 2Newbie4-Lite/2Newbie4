package ransanmoi;

import java.awt.Image;
import java.awt.Point;
import java.util.List;

public class GameConfig {

    // ====== Thông số cơ bản của map ======
    public int mapWidth;         // số ô ngang
    public int mapHeight;        // số ô dọc
    public int speed;            // tốc độ game (ms của Timer)
    public int scoreToWin;       // điểm cần đạt

    // ====== Mục tiêu thắng màn ======
    public Point goalPoint;      // vị trí người chơi phải chạm

    // ====== Danh sách vật cản (toạ độ tile) ======
    public List<Obstacle> obstaclesList;
    // ====== Hình nền map (dùng sau khi tích hợp ImageAssets) ======
    public Image background;  // hiện tại chưa set, chỉ giữ chỗ

    // ====== Constructor rỗng ======
    public GameConfig() {
        // chưa làm gì, chỉ khởi tạo khung
    }

    // ====== Static config cho từng map (để khai báo sau này) ======
    public static GameConfig easy() {
        GameConfig cfg = new GameConfig();
        cfg.mapWidth = 60;
        cfg.mapHeight = 45;
        cfg.speed = 100;
        cfg.background=ImageAssets.bgEasy;
        
        cfg.scoreToWin = 1000;


        // giả sử TILE_SIZE = 20 trong Game
        int tileSize = 20;

        cfg.obstaclesList = List.of(
                new Obstacle(ImageAssets.obstacle1, new Point(10, 10), tileSize),
                new Obstacle(ImageAssets.obstacle1, new Point(49, 10), tileSize),
                new Obstacle(ImageAssets.obstacle1, new Point(10, 34), tileSize),
                new Obstacle(ImageAssets.obstacle1, new Point(49, 34), tileSize)
        );

        return cfg;
    }



    public static GameConfig normal() {
        GameConfig cfg = new GameConfig();
        cfg.mapWidth = 50;
        cfg.mapHeight = 35;
        cfg.speed = 100;
        cfg.background=ImageAssets.bgNormal;

        cfg.scoreToWin = 2000;

        // giả sử TILE_SIZE = 20 trong Game
        int tileSize = 20;

        cfg.obstaclesList = List.of(
                new Obstacle(ImageAssets.Wall1, new Point(0, 0), tileSize),
                new Obstacle(ImageAssets.Wall2, new Point(0, 0), tileSize),
                new Obstacle(ImageAssets.Wall2, new Point(59, 0), tileSize),
                new Obstacle(ImageAssets.Wall3, new Point(1, 20), tileSize),
                new Obstacle(ImageAssets.Wall3, new Point(1, 43), tileSize),
                new Obstacle(ImageAssets.Wall3, new Point(37, 20), tileSize),
                new Obstacle(ImageAssets.Wall3, new Point(37, 43), tileSize),
                new Obstacle(ImageAssets.Wall4, new Point(22, 1), tileSize),
                new Obstacle(ImageAssets.Wall4, new Point(37, 1), tileSize),
                new Obstacle(ImageAssets.Wall5, new Point(22, 15), tileSize),
                new Obstacle(ImageAssets.Wall5, new Point(22, 20), tileSize),
                new Obstacle(ImageAssets.Wall5, new Point(37, 15), tileSize),
                new Obstacle(ImageAssets.Wall5, new Point(37, 20), tileSize),
                new Obstacle(ImageAssets.Wall4, new Point(22, 35), tileSize),
                new Obstacle(ImageAssets.Wall4, new Point(37, 35), tileSize),
                
                new Obstacle(ImageAssets.Sofa1, new Point(4, 34), tileSize),
                new Obstacle(ImageAssets.Sofa1, new Point(16, 34), tileSize),
                new Obstacle(ImageAssets.Sofa2, new Point(4, 38), tileSize),
                new Obstacle(ImageAssets.TV, new Point(6, 22), tileSize)
                
                
        );

        return cfg;
    }

    public static GameConfig hard() {
        GameConfig cfg = new GameConfig();
        cfg.mapWidth = 60;
        cfg.mapHeight = 45;
        cfg.speed = 1000;
        cfg.background=ImageAssets.bgHard;

        cfg.scoreToWin = 2000;

        // giả sử TILE_SIZE = 20 trong Game
        int tileSize = 20;

        cfg.obstaclesList = List.of(
                new Obstacle(ImageAssets.obstacle1, new Point(10, 10), tileSize),
                new Obstacle(ImageAssets.obstacle1, new Point(49, 10), tileSize)
        );

        return cfg;
    }
}
