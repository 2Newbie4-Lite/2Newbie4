package ransanmoi;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import ransanmoi.Snake.Direction;

public class Game extends JPanel implements ActionListener, KeyListener {
    private Score score;

    private MainFrame frame;

    private final int TILE_SIZE = 20;
    

    private final GameBoard board;
    private Snake snake;
    
    private Food food;
    private Food food2;
    private Food food3;


    private boolean running = true;
    private Timer timer;

    private GameConfig config;

    public Game(GameConfig config, MainFrame frame) {
        this.frame = frame;
        this.config = config;

        board = new GameBoard(60, 45);

        // SỬA LỖI: spawn rắn phải nằm trong bản đồ
        snake = new Snake(new Point(20, 44));

        food = new Food(board.getWidth(), board.getHeight());
        food2 = new Food(board.getWidth(), board.getHeight());
        food3 = new Food(board.getWidth(), board.getHeight());
        
        //score
        score = new Score();
        score.setRequiredScore(config.scoreToWin);


// Tạo list tile của obstacle
        java.util.List<Point> obstacleTiles = config.obstaclesList
                .stream()
                .map(Obstacle::getTilePos)
                .toList();

// Respawn lần đầu để đảm bảo KHÔNG null và không dính obstacle
        food.respawn(
                board.getWidth(),
                board.getHeight(),
                obstacleTiles,
                snake
        );
        food2.respawn(
                board.getWidth(),
                board.getHeight(),
                obstacleTiles,
                snake
        );
        food3.respawn(
                board.getWidth(),
                board.getHeight(),
                obstacleTiles,
                snake
        );

        timer = new Timer(config.speed, this);
        timer.start();

        setPreferredSize(new Dimension(board.getWidth() * TILE_SIZE, board.getHeight() * TILE_SIZE));
        setBackground(Color.WHITE);

        setFocusable(true);
        addKeyListener(this);

        SwingUtilities.invokeLater(() -> requestFocusInWindow());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) update();
        repaint();
    }

    private void update() {

        // Tính vị trí đầu mới
        Point nextHead = new Point(snake.getHead());
        switch (snake.getDirection()) {
            case UP -> nextHead.y--;
            case DOWN -> nextHead.y++;
            case LEFT -> nextHead.x--;
            case RIGHT -> nextHead.x++;
        }

        Rectangle headRect = new Rectangle(
                nextHead.x * TILE_SIZE,
                nextHead.y * TILE_SIZE,
                TILE_SIZE,
                TILE_SIZE
        );

        // Va vào thân
        if (snake.contains(nextHead)) {
            running = false;
            frame.showLose();
            return;
        }

        // Va vào obstacle
        if (config.obstaclesList != null) {
            for (Obstacle ob : config.obstaclesList) {
                if (headRect.intersects(ob.getBounds())) {
                    running = false;
                    frame.showLose();
                    return;
                }
            }
        }

        // Di chuyển
        snake.move(board.getWidth(), board.getHeight());

        // Ăn food
        if (snake.getHead().equals(food.getPosition())) {

            snake.grow();
            score.add(100);
            if (score.hasReachedGoal()) {
                running = false;
                frame.showWin();
                return;
            }


            // Chuyển obstacle -> tile position
            java.util.List<Point> obstacleTiles = config.obstaclesList
                    .stream()
                    .map(Obstacle::getTilePos)
                    .toList();

            food.respawn(
                    board.getWidth(),
                    board.getHeight(),
                    obstacleTiles,
                    snake
            );
        }// Ăn food
        if (snake.getHead().equals(food2.getPosition())) {

            snake.grow();
            score.add(100);
            if (score.hasReachedGoal()) {
                running = false;
                frame.showWin();
                return;
            }

            // Chuyển obstacle -> tile position
            java.util.List<Point> obstacleTiles = config.obstaclesList
                    .stream()
                    .map(Obstacle::getTilePos)
                    .toList();

            food2.respawn(
                    board.getWidth(),
                    board.getHeight(),
                    obstacleTiles,
                    snake
            );
        }// Ăn food
        if (snake.getHead().equals(food3.getPosition())) {

            snake.grow();
            score.add(100);
            if (score.hasReachedGoal()) {
                running = false;
                frame.showWin();
                return;
            }

            // Chuyển obstacle -> tile position
            java.util.List<Point> obstacleTiles = config.obstaclesList
                    .stream()
                    .map(Obstacle::getTilePos)
                    .toList();

            food3.respawn(
                    board.getWidth(),
                    board.getHeight(),
                    obstacleTiles,
                    snake
            );
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        

        // Vẽ background
        g.drawImage(config.background, 0, 0, getWidth(), getHeight(), null);

        // Vẽ food
        Point f1 = food.getPosition();
        g.drawImage(ImageAssets.food1, f1.x * TILE_SIZE, f1.y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);

        Point f2 = food2.getPosition();
        g.drawImage(ImageAssets.food1, f2.x * TILE_SIZE, f2.y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);

        Point f3 = food3.getPosition();
        g.drawImage(ImageAssets.food1, f3.x * TILE_SIZE, f3.y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);

        // Vẽ obstacle
        if (config.obstaclesList != null) {
            for (Obstacle ob : config.obstaclesList) {
                ob.draw(g);
            }
        }

        // Vẽ rắn
        Point head = snake.getHead();
        g.drawImage(ImageAssets.snakeHead,
                head.x * TILE_SIZE, head.y * TILE_SIZE,
                TILE_SIZE, TILE_SIZE,
                null);

        java.util.List<Point> body = snake.getBody();
        for (int i = 1; i < body.size(); i++) {
            Point p = body.get(i);

            g.drawImage(ImageAssets.snakeBody,
                    p.x * TILE_SIZE, p.y * TILE_SIZE,
                    TILE_SIZE, TILE_SIZE,
                    null);
        }//Score
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        g.drawString("Score: " + score.getCurrentScore(), 20, 19);

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> snake.setDirection(Direction.UP);
            case KeyEvent.VK_DOWN -> snake.setDirection(Direction.DOWN);
            case KeyEvent.VK_LEFT -> snake.setDirection(Direction.LEFT);
            case KeyEvent.VK_RIGHT -> snake.setDirection(Direction.RIGHT);
        }
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}

}
