package ransanmoi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LosePanel extends JPanel {

    private MainFrame frame;

    private JLabel retryLabel;
    private JLabel menuLabel;

    public LosePanel(MainFrame frame) {
        this.frame = frame;

        setLayout(null); // cho phép đặt ảnh theo tọa độ
        setFocusable(true);

        // ====== TẢI ẢNH ======
        Image retryImg = ImageAssets.restart;   // bạn cần thêm biến này vào ImageAssets
        Image menuImg  = ImageAssets.menu;    // tương tự

        // ====== TẠO LABEL ======
        retryLabel = new JLabel(new ImageIcon(retryImg));
        menuLabel  = new JLabel(new ImageIcon(menuImg));

        // ====== ĐẶT VỊ TRÍ (có thể điều chỉnh tùy ý) ======
        retryLabel.setBounds(
                450,
                350,
                retryImg.getWidth(null),
                retryImg.getHeight(null));

        menuLabel.setBounds(
                450,
                480,
                menuImg.getWidth(null),
                menuImg.getHeight(null));

        // ====== CLICK ======
        retryLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(frame.getLastConfig());   // restart map easy tạm thời
            }
        });

        menuLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.showMenu();
            }
        });

        // ====== THÊM VÀO PANEL ======
        add(retryLabel);
        add(menuLabel);
    }

    // ====== VẼ BACKGROUND ======
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(ImageAssets.bgLose, 0, 0, getWidth(), getHeight(), null);
    }
}
