package ransanmoi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DifficultyPanel extends JPanel {

    private MainFrame frame;

    private JLabel choose1Label;
    private JLabel choose2Label;
    private JLabel choose3Label;
    private JLabel backLabel;

    public DifficultyPanel(MainFrame frame) {
        this.frame = frame;

        setLayout(null); // cho phép đặt ảnh tùy toạ độ

        // ======= LOAD ẢNH =======
        Image img1 = ImageAssets.choose1;
        Image img2 = ImageAssets.choose2;
        Image img3 = ImageAssets.choose3;
        Image imgBack = ImageAssets.back;

        // ======= TẠO LABEL TỪ ẢNH =======
        choose1Label = new JLabel(new ImageIcon(img1));
        choose2Label = new JLabel(new ImageIcon(img2));
        choose3Label = new JLabel(new ImageIcon(img3));
        backLabel    = new JLabel(new ImageIcon(imgBack));

        // ====== ĐẶT VỊ TRÍ ======
        // bạn có thể chỉnh lại theo ý thích
        choose1Label.setBounds(250, 350, img1.getWidth(null), img1.getHeight(null));
        choose2Label.setBounds(550, 350, img2.getWidth(null), img2.getHeight(null));
        choose3Label.setBounds(850, 350, img3.getWidth(null), img3.getHeight(null));

        backLabel.setBounds(20, 20, imgBack.getWidth(null), imgBack.getHeight(null));

        // ====== GẮN SỰ KIỆN CLICK ======
        choose1Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(GameConfig.easy());
            }
        });

        choose2Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(GameConfig.normal());
            }
        });

        choose3Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(GameConfig.hard());
            }
        });

        backLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.showMenu();
            }
        });

        // ====== THÊM VÀO PANEL ======
        add(choose1Label);
        add(choose2Label);
        add(choose3Label);
        add(backLabel);
    }

    // ====== VẼ BACKGROUND ======
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(ImageAssets.bgDifficulty, 0, 0, getWidth(), getHeight(), null);
    }
}
