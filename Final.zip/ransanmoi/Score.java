package ransanmoi;

public class Score {

    // ====== Điểm hiện tại ======
    private int currentScore = 0;

    // ====== Điểm cần để thắng (từ GameConfig) ======
    private int requiredScore = 0;

    // ====== Constructor rỗng ======
    public Score() {
        // hiện tại chưa làm gì
    }

    // ====== Setter để sau này GameConfig gán ======
    public void setRequiredScore(int requiredScore) {
        this.requiredScore = requiredScore;
    }

    // ====== Getter ======
    public int getCurrentScore() {
        return currentScore;
    }

    public int getRequiredScore() {
        return requiredScore;
    }

    // ====== Sau này GamePanel sẽ dùng ======
    public void add(int amount) {
        currentScore += amount;
    }

    public void reset() {
        currentScore = 0;
    }

    // ====== Kiểm tra đủ điểm thắng (chưa sử dụng) ======
    public boolean hasReachedGoal() {
        return currentScore >= requiredScore;
    }
}
