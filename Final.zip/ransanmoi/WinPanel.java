package ransanmoi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WinPanel extends JPanel {

    private MainFrame frame;

    private JLabel restart;
    private JLabel menu;

    public WinPanel(MainFrame frame) {
        this.frame = frame;

        setLayout(null); // sử dụng toạ độ tuyệt đối

        // ====== LOAD ẢNH ======
        Image restartImg = ImageAssets.restart;   // thêm biến trong ImageAssets
        Image menuImg    = ImageAssets.menu;      // cũng thêm vào ImageAssets

        // ====== TẠO  ======
        restart = new JLabel(new ImageIcon(restartImg));
        menu    = new JLabel(new ImageIcon(menuImg));

        // ====== ĐẶT VỊ TRÍ (chỉnh lại tuỳ bạn) ======
        restart.setBounds(
                450,
                350,
                restartImg.getWidth(null),
                restartImg.getHeight(null));

        menu.setBounds(
                450,
                480,
                menuImg.getWidth(null),
                menuImg.getHeight(null));

        // ====== CLICK ======
        restart.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.startGame(frame.getLastConfig());  // restart map easy
            }
        });

        menu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                frame.showMenu();
            }
        });

        // ====== THÊM COMPONENT ======
        add(restart);
        add(menu);
    }

    // ====== BACKGROUND ======
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(ImageAssets.Win, 0, 0, getWidth(), getHeight(), null);
    }
}
