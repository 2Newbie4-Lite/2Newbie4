package ransanmoi;

import javax.swing.*;

public class MainFrame extends JFrame {
    
    private GameConfig lastConfig;  // map hiện tại


    public MainFrame() {

        setTitle("Snake Game");
        setSize(1217, 940);  // kích thước cố định như bạn yêu cầu
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Chưa thêm bất kỳ panel nào.
        // Bạn sẽ thêm vào sau bằng:
        // setContentPane(new MenuPanel());
        // hoặc setContentPane(new GamePanel());
        // nhưng bây giờ KHÔNG LÀM GÌ.
    }public void showMenu() {
        setContentPane(new MenuPanel(this));
        revalidate();
        repaint();
    }

    public void showDifficulty() {
        setContentPane(new DifficultyPanel(this));
        revalidate();
        repaint();
    }

    public void startGame(GameConfig config) {
        this.lastConfig=config;
        Game g = new Game(config, this);
        setContentPane(g);
        revalidate();
        repaint();

        g.requestFocusInWindow();    //Game bị phải click lại màn hình mới chạy
    }


    public void showWin() {
        setContentPane(new WinPanel(this));
        revalidate();
        repaint();
    }

    public void showLose() {
        setContentPane(new LosePanel(this));
        revalidate();
        repaint();
    }
    
    public GameConfig getLastConfig() {
        return lastConfig;
    }

    

    

    // Hàm main tạm thời chỉ để test frame
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mf = new MainFrame();
            mf.setVisible(true);
        });
    }
}
